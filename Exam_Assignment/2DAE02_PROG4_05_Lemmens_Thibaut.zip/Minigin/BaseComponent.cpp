#include "MiniginPCH.h"
#include "BaseComponent.h"


BaseComponent::BaseComponent() : m_pGameObject(nullptr)
{
}
